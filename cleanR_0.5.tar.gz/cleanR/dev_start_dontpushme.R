#clean start
rm(list=ls())


#load packages
library(pander)
library(ggplot2)
library(rmarkdown)


#run everything
source("./R/leftover_functions_split_us.R")

source("./R/smartNum.R")
source("./R/messageGenerator.R")
source("./R/oClass.R")
source("./R/render.R")
source("./R/description.R")
source("./R/classes.R")
source("./R/allXFunctions.R")
source("./R/makeXFunction.R")
source("./R/identifyNums.R")


source("./R/summaryFunction.R")
source("./R/visualFunction.R")
source("./R/checkFunction.R")

source("./R/allSummaryFunctions.R")
source("./R/allVisualFunctions.R")
source("./R/allCheckFunctions.R")

source("./R/visualize.R") #okko
source("./R/standardVisual.R") #okko
source("./R/basicVisual.R") #okko
#source("./R/fancyVisual.R") #code not done!

source("./R/summarize.R") #okko
source("./R/quartiles.R") #okko
source("./R/minMax.R") #okko
source("./R/centralValue.R") #okko
source("./R/variableType.R") #okko
source("./R/countMissing.R") #okko
source("./R/uniqueValues.R") #okko

source("./R/check.R")
source("./R/identifyCaseissues.R") #okk
source("./R/identifyOutliers.R") #okk
source("./R/identifyLoners.R") #okk
source("./R/identifyWhitespace.R") #okk
source("./R/identifyMissing.R") #okk
source("./R/isCPR.R") #okko
source("./R/isKey.R") #okko
source("./R/isEmpty.R") #okko

source("./R/clean.R")

#source("makeData.R")
load("./data/testData.Rmd")

############
#okko 
#- okk + har tjekket at class() kaldes korrekt + alle summary functions er defineret som
#   summaryFunction, samme med checkFunction og visualFunction.
#
#
#okk
#- ok + har tilføjet export på alle s3-metoder 
#
#
#ok: 
#- første udkast til dokumentation færdigt
#- har tjekket at argumenter er konsistente mellem generiske s3 funktioner og metoder
#- har tilføjet importFrom 
#- har rettet T/F til TRUE/FALSE
#- har slettet unødige kommentarer
#- har slettet argumenter der ikke bruges
#- har tilføjet descriptions til alle dokumenterede funktioner

