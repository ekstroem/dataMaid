
#' document me!
#'
#' @export
allVisualFunctions <- function() {
  allXFunctions("visualFunction")
}

