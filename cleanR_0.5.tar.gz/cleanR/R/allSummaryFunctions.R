#' document me!
#' @export
allSummaryFunctions <- function() {
  allXFunctions("summaryFunction")
}
