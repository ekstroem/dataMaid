#' document me!
#' @export
allCheckFunctions <- function() {
  allXFunctions("checkFunction")
}
