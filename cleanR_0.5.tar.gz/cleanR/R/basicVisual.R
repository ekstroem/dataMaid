#' Produce distribution plots in the base R (graphics) style using \code{\link{plot}} and
#' \code{\link{barplot}}
#'
#' Plot the distribution of a variable, depending on its data class, using the base R
#' plotting functions.
#'
#' For character, factor, logical and labelled variables, a barplot is produced. For numeric
#' or integer variables, \code{basicVisual} produces a histogram instead. Note that for
#' integer and numeric variables, all non-finite (i.e. \code{NA}, \code{NaN}, \code{Inf}) values are
#' removed prior to plotting. For character, factor, labelled and logical variables, only \code{NA}
#' values are removed.
#'
#' @inheritParams standardVisual
#'
#' @examples
#'  \dontrun{
#'  #Save a variable
#'    myVar <- c(1:10)
#'  #Plot a variable
#'    basicVisual(myVar, "MyVar")
#'
#'  #Produce code for plotting a variable
#'    basicVisual(myVar, "MyVar", doEval = FALSE)
#'  }
#' @seealso \code{\link{visualize}}, \code{\link{standardVisual}}
#'
#' @inheritParams standardVisual
#' @importFrom stats na.omit
#' @importFrom graphics plot hist
#' @export
basicVisual <- function(v, vnam, doEval = TRUE) UseMethod("basicVisual")
basicVisual <- visualFunction(basicVisual, "Histograms and barplots using graphics")

#assign methods to generic standardVisual function

#' @export
basicVisual.character <- function(v, vnam, doEval = TRUE) basicVisualCFLB(v, vnam, doEval=doEval)

#' @export
basicVisual.factor <- function(v, vnam, doEval = TRUE) basicVisualCFLB(v, vnam, doEval=doEval)

#' @export
basicVisual.labelled <- function(v, vnam, doEval = TRUE) basicVisualCFLB(v, vnam, doEval=doEval)

#' @export
basicVisual.numeric <- function(v, vnam, doEval = TRUE) basicVisualIN(v, vnam, doEval=doEval)

#' @export
basicVisual.integer <- function(v, vnam, doEval = TRUE) basicVisualIN(v, vnam, doEval=doEval)

#' @export
basicVisual.logical <- function(v, vnam, doEval = TRUE) basicVisualCFLB(v, vnam, doEval=doEval)




##########################################Not exported below#########################################

##character, factor, labelled and logical variables
#' importFrom stats na.omit
#' @inheritParams standardVisual
basicVisualCFLB <- function(v, vnam, doEval = TRUE) {
  v <- as.factor(v)
  thisCall <- call("plot", x=na.omit(v), main=vnam)
  if (doEval) {
    return(eval(thisCall))
  } else return(deparse(thisCall))
}

#numeric and integer variables
basicVisualIN <- function(v, vnam, doEval = TRUE) {
  v <- v[is.finite(v)]
  thisCall <- call("hist", v, main=vnam, col="grey", xlab="")
  if (doEval) {
    return(eval(thisCall))
  } else return(deparse(thisCall))
}


